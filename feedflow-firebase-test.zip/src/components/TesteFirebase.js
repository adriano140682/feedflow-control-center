import { db } from "../firebase";
import { collection, addDoc } from "firebase/firestore";

export default function TesteFirebase() {
  const salvarNoBanco = async () => {
    try {
      await addDoc(collection(db, "teste"), {
        nome: "Adriano",
        produto: "Ração",
        quantidade: 100,
        data: new Date()
      });
      alert("✅ Salvo no Firestore com sucesso!");
    } catch (e) {
      console.error("❌ Erro ao salvar: ", e);
      alert("Erro ao salvar no Firebase.");
    }
  };

  return (
    <button onClick={salvarNoBanco} style={{
      padding: 12,
      backgroundColor: "#111",
      color: "#fff",
      border: "none",
      borderRadius: 6,
      cursor: "pointer"
    }}>
      Testar conexão com Firebase
    </button>
  );
}
