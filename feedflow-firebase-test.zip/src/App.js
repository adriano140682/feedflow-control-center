import TesteFirebase from "./components/TesteFirebase";

function App() {
  return (
    <div style={{ padding: 40 }}>
      <h1 style={{ color: "#fff" }}>FeedFlow - Teste Firebase</h1>
      <TesteFirebase />
    </div>
  );
}

export default App;
